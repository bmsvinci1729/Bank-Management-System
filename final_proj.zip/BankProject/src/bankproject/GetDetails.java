/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bankproject;

import java.math.BigInteger;

/**
 *
 * @author adithya
 */
public class GetDetails {
    public static String Username;
    public static String RecUsername;
    public static String transType;
    public static int loanTaken = 0;
   
    public static long loanStartTime = 0;
    //public static long systemStartTime = 0;
    //public static long loanEndTime = 0;
    public static long loanTimeElapsed = 0;
   
    public static BigInteger amount = BigInteger.valueOf(0);
    public static BigInteger amountDeposited = BigInteger.valueOf(0);
    public static BigInteger amountWithdrawn = BigInteger.valueOf(0);
    public static BigInteger amountTransferred = BigInteger.valueOf(0);
    public static BigInteger loanAmount = BigInteger.valueOf(0);
    public static BigInteger requiredLoanAmount = BigInteger.valueOf(0);
    public static BigInteger repayedLoanAmount = BigInteger.valueOf(0);
}